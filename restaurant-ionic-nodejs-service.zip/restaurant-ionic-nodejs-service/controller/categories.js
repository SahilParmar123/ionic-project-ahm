const jwt = require('jsonwebtoken');
var secret = 'restaurant-ionic-app';
const Category = require('../models/categories');
const passport = require('passport');

exports.createCategory = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            var category = new Category(req.body);
            Category.createCategory(category, function (err, category) {
                if (err) return res.json({ err, status: 'error' });
                if (category) {
                    return res.json({
                        status: 200,
                        message: 'Category added..!',
                        data: category
                    });
                }
            });
        }
    });
}

exports.updateCategory = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            var category = req.body;
            Category.updateCategory(category, function (err, result) {
                if (err) return res.json({status: 301, message: err, data:null});
                if (result) {
                    return res.json({
                        status: 200,
                        message: 'Category updated..!',
                        data: category
                    });
                }
            });
        }
    });
}

exports.getAllCategory = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            Category.getAllCategory(function (err, categories) {
                if (err) return res.json({status: 301, message: err, data:null});
                if (categories) {
                    return res.json({
                        status: 200,
                        message: 'Category list..!',
                        data: categories
                    });
                }
            });
        }
    });
}