const mongoose = require('mongoose');

const restaurantSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true },
    name: { type: String, require: true },
    timezone :{type: String, require: true},
    languageId: { type: String },
    dayStartTime:{type:String},
    country:{type:String},
    city:{type:String},
    state:{type:String},
    area:{type:String},
    endOfMiseEnPlaceTime:{type:String},
    pushToDoListTime:{type:String},
    pushReportTime:{type:String},
    colorScheme:{type:Number},
    workDays:{type:String},
    showWorkDaysAhead:{type:String},
    statusIndicator:{type:Boolean},
    status:{type:String},
    createdDate:{type:Date}
});


var Restaurant = module.exports = mongoose.model('Restaurant', restaurantSchema);

module.exports.createRestaurant = function (restaurant, callback) {
    restaurant.save(callback);
}

module.exports.updateRestaurant = function (restaurant, callback) {
    Restaurant.updateOne({ _id: restaurant._id }, { $set: restaurant }, callback); 
}

module.exports.getAllRestaurant = function (callback){
    var query = {'statusIndicator': true};
    Restaurant.find(query, callback);
}