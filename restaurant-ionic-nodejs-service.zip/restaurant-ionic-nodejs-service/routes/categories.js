
var express = require('express'),
router = express.Router(),
categoriesController = require('../controller/categories');

router.post('/createCategory', verifyToken, categoriesController.createCategory);
router.post('/updateCategory', verifyToken, categoriesController.updateCategory);
router.get('/getAllCategory', verifyToken, categoriesController.getAllCategory);

function verifyToken (req, res, next) {
    const bearerHeader = req.headers['authorization'];
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        req.token = bearerToken;
        next();
    } else {
        //Forbidden
        //return res.status(403);
        next();
    }
}

module.exports = router; 