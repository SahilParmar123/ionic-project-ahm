const mongoose = require('mongoose');

const taskImagesSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true },
    taskId: { type: String, require: true },
    imageIndex: { type: Number },
    image: { type: String}
});


var TaskImage = module.exports = mongoose.model('TaskImage', taskImagesSchema);