const mongoose = require('mongoose');

const langMasterSchema = mongoose.Schema({
    languagecode: { type: String, require: true },
    languagetitle: { type: String },
    languagedirection: { type: String }
});


var LanguageMaster = module.exports = mongoose.model('LanguageMaster', langMasterSchema);

module.exports.addMasterLanguage = function (language, callback){
    language.save(callback);
}

module.exports.getAllLanguages = function (callback){
    // LanguageMaster.find(callback);
    LanguageMaster.aggregate([
        //Group by fields and get all data
        { "$group": { "_id": "$languagecode", "languagecode": { "$first": "$$ROOT" } } },
        { "$replaceRoot": { "newRoot": "$languagecode" } }
    ]).exec(callback);
}