const jwt = require('jsonwebtoken');
var secret = 'restaurant-ionic-app';
const User = require('../models/users');
const EmailTemp = require('../models/emailTemplates');
const UserTypeUsers = require('../models/userTypeUsers');
const passport = require('passport');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');

exports.login = function (req, res, next) {

    passport.authenticate("local", function (err, user, info) {
        if (err) return next(err);
        if (!user) {
            return res.status(401).json({
                status: 'error',
                code: 'Unauthorized'
            });
        } else {
            jwt.sign({ user }, secret, (err, token) => {
                res.json({
                    token: token,
                    user: user
                });
            });
        }
    })(req, res, next);

};

exports.register = function (req, res) {
    var user = new User(req.body);
    User.createUser(user, function (err, user) {
        if (err) return res.json({ err, status: 'error' });
        if (user) {
            UserTypeUsers.createUserType(user, function (err, userTypeUser) {
                if (err) return res.json({ err, status: 'error' });
                if (userTypeUser) {
                    return res.json({
                        status: 200,
                        message: 'User Created..!',
                        data: user
                    });
                }
            });
        }
    });
};

exports.forgotPassword = function (req, res) {

    var email = req.body.email;
    var newPass;
    User.findOne({
        email: email
    }, function (err, userObj) {
        if (err) return res.json({
            err,
            status: 'error'
        });

        if (userObj.length != 0) {
            newPass = Math.floor(100000 + Math.random() * 900000);
            var user = userObj;
            user.password = newPass;
            var tomail = user.email;

            User.updateUserPassword(user, function (err, user) {
                if (err) return res.json({
                    message: err,
                    status: 1
                });
                if (user) {

                    var transporter = nodemailer.createTransport({
                        host: 'mail.versionreview.com',
                        port: 465,
                        auth: {
                            user: 'phpdeveloper@versionreview.com',
                            pass: 'Dev@123!@#'
                        }
                    });

                    var mailOptions = {
                        from: 'no-reply@versionreview.com',
                        to: tomail,
                        subject: 'New Password - M.E.P Management',
                        html: "<b>Your New Password: </b>" + newPass + "<br><a href=https://167.114.3.106:8080/> Click here to Login</a><br><h5 style='color:red'>Note:You can change your password from profile</h5>"
                    };

                    transporter.sendMail(mailOptions, function (error, info) {
                        if (error) {
                            console.log(error);
                            return res.json({
                                status: 301,
                                message: error.message,
                                data: null
                            });
                        } else {
                            return res.json({
                                status: 200,
                                message: "Mail has been sent..",
                                data: null
                            });
                            // console.log('Email sent: ' + info.response);
                        }
                    });
                }
            });
        } else {
            return res.json({
                message: "Not found",
                status: 'error'
            });
        }
    });
}

exports.changePassword = function (req, res) {
    if (req.token != null) {
        jwt.verify(req.token, secret, function (err, loggedInUser) {
            if (err) {
                return res.status(403);
            } else {
                var currentpassword = req.body.currentpassword;
                var newpassword = req.body.newpassword;
                var l_user = loggedInUser.user;
                bcrypt.compare(currentpassword, l_user.password, function (bcryterr, status) {
                    if (status) {
                        l_user.password = newpassword;
                        User.updateUserPassword(l_user, function (err, user) {
                            if (err) return res.json({ message: err, status: 1 });
                            if (user) {
                                return res.json({
                                    message: "Password has changed..!",
                                    status: 200
                                });
                            }
                        });
                    } else {
                        return res.json({
                            message: bcryterr,
                            status: 1
                        });
                    }
                });
            }
        });
    } else {
        return res.json({
            message: "Token is not define..!",
            status: 1
        });
    }

}

exports.resetPassword = function (req, res) {
    var user_id = req.body._id;
    User.findOne({
        _id: user_id
    }, function (err, userObj) {
        if (err) return res.json({
            err,
            status: 'error'
        });

        if (userObj.length != 0) {
            var newPass = req.body.password;
            var user = userObj;
            user.password = newPass;
            User.updateUserPassword(user, function (err, user) {
                if (err) return res.json({
                    message: err,
                    status: 1
                });
                if (user) {
                    return res.json({
                        message: "Password has changed..!",
                        status: 200
                    });
                }
            });
        } else {
            return res.json({
                message: "Not found",
                status: 'error'
            });
        }
    });
}

exports.resetPasswordEmail = function (req, res) {
    if (req.token != null) {
        jwt.verify(req.token, secret, function (err, user) {
            if (err) {
                return res.status(403);
            } else {
                const nUser = req.body;
                EmailTemp.findOne({
                    language_code: nUser.languageId,
                    email_type: 'password-reset'
                }, function (err, emailTempObj) {
                    if (err) return res.json({
                        status: 301,
                        message: err.message,
                        data: null
                    });
                    if (emailTempObj) {
                        var mainMessage = "";
                        var message = emailTempObj.email_message;
                        mainMessage = message.replace("[SiteTitle]", "www.mep.com");
                        mainMessage = mainMessage.replace("[FirstName]", nUser.name);
                        mainMessage = mainMessage.replace("[LastName]", nUser.name);
                        mainMessage = mainMessage.replace("[UserName]", nUser.email);
                        mainMessage = mainMessage.replace("[Email]", nUser.email);
                        mainMessage = mainMessage.replace("[RefLink]", "http://167.114.3.106:8080/MEP/#/pages/resetpassword/" + nUser._id);
                        mainMessage = mainMessage.replace("[RefLink]", "Click Here..");
                        console.log(mainMessage);

                        var transporter = nodemailer.createTransport({
                            host: 'mail.versionreview.com',
                            port: 465,
                            auth: {
                                user: 'phpdeveloper@versionreview.com',
                                pass: 'Dev@123!@#'
                            }
                        });

                        var mailOptions = {
                            from: 'no-reply@versionreview.com',
                            to: nUser.email,
                            subject: 'Reset Password - M.E.P Management',
                            html: mainMessage
                        };

                        transporter.sendMail(mailOptions, function (error, info) {
                            if (error) {
                                console.log(error);
                                return res.json({
                                    status: 301,
                                    message: error.message,
                                    data: null
                                });
                            } else {
                                return res.json({
                                    status: 200,
                                    message: "Mail has been sent..",
                                    data: null
                                });
                            }
                        });
                    } else {
                        return res.json({
                            message: "Not found",
                            status: 'error'
                        });
                    }
                });



            }
        });
    } else {
        return res.json({
            message: "Token is not define..!",
            status: 1
        });
    }


}


