const User = require('../models/users');
const EmailTemp = require('../models/emailTemplates');
const UserTypeUser = require('../models/userTypeUsers');
const jwt = require('jsonwebtoken');
var secret = 'restaurant-ionic-app';
var multer = require('multer');
var path = require('path');
var fs = require('fs');
//const DOCPATH = 'D:/Sahil/Ahmdabad/restaurant-ionic-nodejs-service/uploads';
const DOCPATH = '/var/www/MEP_Service/uploads';
//const DBIMGPATH = '/assets/Fileupload';
const DBIMGPATH = '/uploads';
const nodemailer = require('nodemailer');

exports.createUser = function (req, res) {

    var user = new User(req.body);
    User.createUser(user, function (err, user) {
        if (err) return res.json({ err, status: 'error' });
        if (user) {
            var num = Math.floor(Math.random() * 90000) + 10000;
            user.userCode = new Date().getFullYear() + "USER" + num;
            UserTypeUser.createUserType(user, function (err, user) {
                if (err) return res.json({ err, status: 'error' });
                if (user) {
                    return res.json({
                        status: 200,
                        message: 'User Created..!',
                        data: user
                    });
                }
            });
        }
    });
};

exports.getAllUsers = function (req, res) {
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.status(403);
        } else {
            User.getAllUsers(function (err, usersList) {
                if (err) throw err;
                if (usersList) {
                    return res.json({
                        status: 200,
                        message: '',
                        data: usersList
                    });
                }
            });
        }
    });
}

exports.getAllUsersById = function (req, res) {
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.status(403);
        } else {
            var _ids = req.body._ids;
            User.getAllUsersById(_ids, function (err, usersList) {
                if (err) throw err;
                if (usersList) {
                    return res.json({
                        status: 200,
                        message: '',
                        data: usersList
                    });
                }
            });
        }
    });
}

exports.delete = function (req, res) {
    jwt.verify(req.token, secret, function (err, loggedInUser) {
        if (err) {
            return res.status(403);
        } else {
            const userId = req.body._id;
            var user = loggedInUser.user;
            User.deleteUser(userId, function (err, result) {
                if (err) throw err;
                if (result) {
                    return res.json({
                        status: 200,
                        message: 'User deleted success..!',
                        data: user
                    });
                }
            });
        }
    });
}

exports.updateUser = function (req, res) {
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.status(403);
        } else {
            const userId = req.body._id;
            const updateUser = req.body;
            User.updateUser(userId, updateUser, function (err, result) {
                if (err) throw err;
                if (result) {
                    return res.json({
                        message: 'Update success..!',
                        status: 200,
                        data: updateUser
                    });
                }
            });
        }
    });
}

exports.changeEmail = function (req, res) {
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.status(403);
        } else {
            const nUser = user.user;
            User.sentEmail(nUser, function (err, result) {
                if (err) return res.json({
                    message: err,
                    status: 301,
                    data: null
                });
                if (result) {
                    return res.json({
                        message: 'Email sent success!',
                        status: 200,
                        data: null
                    });
                }
            });
        }
    });
}

exports.triggerEmail = function (req, res) {
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.status(403);
        } else {
            const nUser = req.body;
            EmailTemp.findOne({
                language_code: nUser.languageId,
                email_type: 'welcome'
            }, function (err, emailTempObj) {
                if (err) return res.json({
                    err,
                    status: 'error'
                });
                if (emailTempObj) {
                    var mainMessage = "";
                    var message = emailTempObj.email_message;
                    mainMessage = message.replace("[SiteTitle]", "www.mep.com");
                    mainMessage = mainMessage.replace("[FirstName]", nUser.name);
                    mainMessage = mainMessage.replace("[LastName]", nUser.name);
                    mainMessage = mainMessage.replace("[UserName]", nUser.email);
                    mainMessage = mainMessage.replace("[Email]", nUser.email);
                    mainMessage = mainMessage.replace("[ActionLink]", "http://167.114.3.106:8080/MEP");
                    
                    console.log(mainMessage);

                    var transporter = nodemailer.createTransport({
                        host: 'mail.versionreview.com',
                        port: 465,
                        auth: {
                            user: 'phpdeveloper@versionreview.com',
                            pass: 'Dev@123!@#'
                        }
                    });

                    var mailOptions = {
                        from: 'no-reply@versionreview.com',
                        to: nUser.email,
                        subject: 'Welcome - M.E.P Management',
                        html: mainMessage
                    };

                    transporter.sendMail(mailOptions, function (error, info) {
                        if (error) {
                            console.log(error);
                            return res.json({
                                status: 301,
                                message: error.message,
                                data: null
                            });
                        } else {
                            return res.json({
                                status: 200,
                                message: "Mail has been sent..",
                                data: null
                            });
                        }
                    });
                } else {
                    return res.json({
                        message: "Not found",
                        status: 'error'
                    });
                }
            });

            

        }
    });
}

exports.getLoggedInUser = function (req, res) {
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({
                message: err,
                status: -1,
                data: null
            });
        } else {
            return res.json({
                message: '',
                status: 200,
                data: user
            });
        }
    });
}

exports.profileImageChange = function (req, res) {
    jwt.verify(req.token, secret, function (err, loggedInUser) {
        if (err) {
            return res.status(403);
        } else {
            var user = loggedInUser.user;
            var mainPath = DOCPATH;
            var imgPath = '/admin/';
            var imgFullPath = mainPath + imgPath;
            var filepath = '';

            if (fs.existsSync(imgFullPath)) {

                var user_id = user._id;
                var final_path = imgFullPath + user_id;
                var storage = multer.diskStorage({
                    destination: function (req, file, callback) {
                        callback(null, final_path)
                    },
                    filename: function (req, file, callback) {
                        filepath = file.fieldname + '-' + Date.now() + path.extname(file.originalname);
                        callback(null, filepath);
                    }
                });
                if (fs.existsSync(final_path)) {
                    // Do something
                    var upload = multer({
                        storage: storage,
                        limits: { fileSize: 100000000 },
                        fileFilter: function (req, file, callback) {
                            var ext = path.extname(file.originalname);
                            if (ext !== '.jpg' && ext !== '.png' && ext !== '.gif') {
                                return callback(res.end('Only Images are allowed'), null)
                            }
                            callback(null, true);
                        }
                    }).single('file');
                    upload(req, res, function (err) {

                        if (err) return res.json({ err, status: 'error' });

                        // Client.findById(companyId, function (err, client) {
                        //     if (err) {
                        //         return res.json({ message: err });
                        //     }
                        //     if (client) {                                   

                        //         client.filePath =  DBIMGPATH + imgPath + user_id + '/' + filepath; 
                        //         Client.updateclientimage(client, function (err, result) {
                        //             if (err) {
                        //                 return res.json({ message: err });
                        //             }
                        //             if (result) {
                        //                 fileList = [];
                        //                 return res.json({
                        //                     status: 200,
                        //                     message: 'Document updated..'
                        //                 });
                        //             }
                        //         })
                        //     }
                        // });
                        user.image = DBIMGPATH + imgPath + user_id + '/' + filepath;
                        User.updateUser(user._id, user, function (err, result) {
                            if (err) throw err;
                            if (result) {
                                return res.json({
                                    message: 'Update success..!',
                                    status: 200,
                                    data: user
                                });
                            }
                        });
                    });
                } else {
                    fs.mkdir(final_path, { recursive: true }, function (err) {
                        if (err) {
                            console.log('failed to create directory', err);
                        } else {

                            var upload = multer({
                                storage: storage,
                                limits: { fileSize: 100000000 },
                                fileFilter: function (req, file, callback) {
                                    var ext = path.extname(file.originalname)
                                    if (ext !== '.jpg' && ext !== '.png' && ext !== '.gif') {
                                        return callback(res.end('Only Images are allowed'), null)
                                    }
                                    callback(null, true);
                                }
                            }).single('file');

                            upload(req, res, function (err) {
                                // res.end('File is uploaded')
                                if (err) return res.json({ err, status: 'error' });

                                user.image = DBIMGPATH + imgPath + user_id + '/' + filepath;
                                User.updateUser(user._id, user, function (err, result) {
                                    if (err) throw err;
                                    if (result) {
                                        return res.json({
                                            message: 'Update success..!',
                                            status: 200,
                                            data: user
                                        });
                                    }
                                });
                                // Client.findById(companyId, function (err, client) {
                                //     if (err) {
                                //         return res.json({ message: err });
                                //     }
                                //     if (client) {
                                //         client.filePath = fileList;                                            
                                //         client.updatedDate = new Date();
                                //         Client.updateclientimage(client, function (err, result) {
                                //             if (err) {
                                //                 return res.json({ message: err });
                                //             }
                                //             if (result) {
                                //                 fileList = [];
                                //                 return res.json({
                                //                     status: 200,
                                //                     message: 'Document updated..'
                                //                 });
                                //             }
                                //         })
                                //     }
                                // });
                            });
                        }
                    });
                }
            } else {
                console.log('Path is not available in :- ' + imgFullPath);
                fs.mkdir(imgFullPath, { recursive: true }, function (err) {
                    if (err) {
                        console.log('failed to create directory', err);
                    }
                    var user_id = user._id;
                    var final_path = imgFullPath + user_id;
                    var storage = multer.diskStorage({
                        destination: function (req, file, callback) {
                            callback(null, final_path)
                        },
                        filename: function (req, file, callback) {
                            filepath = file.fieldname + '-' + Date.now() + path.extname(file.originalname);
                            callback(null, filepath);
                        }
                    });
                    if (fs.existsSync(final_path)) {
                        // Do something
                        var upload = multer({
                            storage: storage,
                            limits: { fileSize: 100000000 },
                            fileFilter: function (req, file, callback) {
                                var ext = path.extname(file.originalname)
                                if (ext !== '.jpg' && ext !== '.png' && ext !== '.gif') {
                                    return callback(res.end('Only Images are allowed'), null)
                                }
                                callback(null, true);
                            }
                        }).single('file');


                        upload(req, res, function (err) {

                            if (err) return res.json({ err, status: 'error' });

                            user.image = DBIMGPATH + imgPath + user_id + '/' + filepath;
                            User.updateUser(user._id, user, function (err, result) {
                                if (err) throw err;
                                if (result) {
                                    return res.json({
                                        message: 'Update success..!',
                                        status: 200,
                                        data: user
                                    });
                                }
                            });
                            // Client.findById(companyId, function (err, client) {
                            //     if (err) {
                            //         return res.json({ message: err });
                            //     }
                            //     if (client) {
                            //         client.filePath = fileList;                                       
                            //         client.updatedDate = new Date();
                            //         Client.updateclientimage(client, function (err, result) {
                            //             if (err) {
                            //                 return res.json({ message: err });
                            //             }
                            //             if (result) {
                            //                 fileList = [];
                            //                 return res.json({
                            //                     status: 200,
                            //                     message: 'Document updated..'
                            //                 });
                            //             }
                            //         })
                            //     }
                            // });
                        });
                    } else {
                        fs.mkdir(final_path, { recursive: true }, function (err) {
                            if (err) {
                                console.log('failed to create directory', err);
                            } else {

                                var upload = multer({
                                    storage: storage,
                                    limits: { fileSize: 100000000 },
                                    fileFilter: function (req, file, callback) {
                                        var ext = path.extname(file.originalname)
                                        if (ext !== '.jpg' && ext !== '.png' && ext !== '.gif') {
                                            return callback(res.end('Only Images are allowed'), null)
                                        }
                                        callback(null, true);
                                    }
                                }).single('file');

                                upload(req, res, function (err) {
                                    // res.end('File is uploaded')
                                    if (err) return res.json({ err, status: 'error' });

                                    user.image = DBIMGPATH + imgPath + user_id + '/' + filepath;
                                    User.updateUser(user._id, user, function (err, result) {
                                        if (err) throw err;
                                        if (result) {
                                            return res.json({
                                                message: 'Update success..!',
                                                status: 200,
                                                data: user
                                            });
                                        }
                                    });
                                    // Client.findById(companyId, function (err, client) {
                                    //     if (err) {
                                    //         return res.json({ message: err });
                                    //     }
                                    //     if (client) {
                                    //         client.filePath = fileList;                                               
                                    //         client.updatedDate = new Date();
                                    //         Client.updateclientimage(client, function (err, result) {
                                    //             if (err) {
                                    //                 return res.json({ message: err });
                                    //             }
                                    //             if (result) {
                                    //                 fileList = [];
                                    //                 return res.json({
                                    //                     status: 200,
                                    //                     message: 'Document updated..'
                                    //                 });
                                    //             }
                                    //         })
                                    //     }
                                    // });
                                });
                            }
                        });
                    }
                });
            }
        }
    });
}
