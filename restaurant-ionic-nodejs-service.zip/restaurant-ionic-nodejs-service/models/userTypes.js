const mongoose = require('mongoose');

const userTypesSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true, unique: true },
    userTypeId :{type: String, require: true,},
    name: { type: String, require: true },
    abbreviation: { type: String },
    image: { type: String, require: true },
    systemTypeIndicator: { type: String },
    color:{type:String},
    sortOrder:{type:Number}
});


var UserTypes = module.exports = mongoose.model('UserTypes', userTypesSchema);