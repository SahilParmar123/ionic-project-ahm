const jwt = require('jsonwebtoken');
var secret = 'restaurant-ionic-app';
const EmailTemplate = require('../models/emailTemplates');

exports.updateEmailTemplate = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            var emailTemp = req.body;
            EmailTemplate.updateEmailTemplate(emailTemp, function (err, result) {
                if (err) return res.json({status: 301, message: err, data:null});
                if (result) {
                    return res.json({
                        status: 200,
                        message: 'Email Template is updated..!',
                        data: emailTemp
                    });
                }
            });
        }
    });
}

exports.getAllEmailTemplate = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            EmailTemplate.getAllEmailTemplates(function (err, emailTempList) {
                if (err) return res.json({status: 301, message: err, data:null});
                if (emailTempList) {
                    return res.json({
                        status: 200,
                        message: '',
                        data: emailTempList
                    });
                }
            });
        }
    });
}

exports.getAllEmailTemplatesByEmailType = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            var type = req.body.email_type;
            EmailTemplate.getAllEmailTemplatesByEmailType(type, function (err, emailTempList) {
                if (err) return res.json({status: 301, message: err, data:null});
                if (emailTempList) {
                    return res.json({
                        status: 200,
                        message: '',
                        data: emailTempList
                    });
                }
            });
        }
    });
}

