const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');

const userSchema = mongoose.Schema({
    email: { type: String, require: true, unique: true },
    name: { type: String, require: true, },
    initials: { type: String, require: true },
    image: { type: String },
    password: { type: String, require: true },
    languageId: { type: String },
    userCode: { type: String },
    status:{type:Boolean},
    userType:{type: String}
});


var User = module.exports = mongoose.model('User', userSchema);

module.exports.createUser = function (user, callback) {
    bcrypt.genSalt(10, function (err, salt) {
        bcrypt.hash(user.password, salt, function (err, hash) {
            user.password = hash;
            user.save(callback);
        });
    });
}

module.exports.updateUserPassword = function (user, callback) {
    bcrypt.genSalt(10, function (err, salt) {
        bcrypt.hash(user.password, salt, function (err, hash) {
            user.password = hash;
            User.updateOne({ _id: user._id }, { $set: user }, callback);
        });
    });
}


module.exports.getUserByName = function (email, callback) {
    var query = { 'email': email };
    User.findOne(query, callback);
}

module.exports.comparePassword = function (candidatePassword, hash, callback) {

    bcrypt.compare(candidatePassword, hash, function (err, isMatch) {
        if (err) throw err;
        callback(null, isMatch);
    });
}

module.exports.getUserByID = function (_id, callback) {
    User.findById(_id, callback);
}

module.exports.getAllUsers = function (callback) {
    User.find(callback);
}

module.exports.deleteUser = function (_id, callback) {
    var query = { status: false };
    User.update({ _id: _id }, { $set: query }, callback);
}

module.exports.updateUser = function (userId, newUser, callback) {
    User.updateOne({ _id: userId }, { $set: newUser }, callback);
}

module.exports.getAllUsersById = function (ids, callback) {
    // User.find(callback);
    var query = { "userCode": { $in: ids } };
    User.find(query, callback);
}

module.exports.sentEmail = function (newUser, callback) {
    // User.updateOne({ _id: userId }, { $set: newUser }, callback);

    
    var transporter = nodemailer.createTransport({
        host: 'mail.versionreview.com',
        port: 465,
        auth: {
            user: 'phpdeveloper@versionreview.com',
            pass: 'Dev@123!@#'
        }
    });

    var mailOptions = {
        from: 'no-reply@versionreview.com',
        to: newUser.email,
        subject: 'Change E-mail - M.E.P Management',
        html: "<b>Your New Email: </b> <br><a href=https://167.114.3.106:8080/MEP/#/changeemail/"+newUser._id+"> Click here</a><br><h5 style='color:red'>Note:You can change your email from here.</h5>"
    };

    transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
            console.log(error);
            callback();
        } else {
            callback();
        }
    });
}

