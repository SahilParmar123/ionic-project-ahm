const mongoose = require('mongoose');

const tasksTodoBySchema = mongoose.Schema({
    dateIndicator:{type:String},
    restaurantCode: { type: String},
    taskId: { type: Number },
    userCode: { type: String}
});


var TasksTodoBy = module.exports = mongoose.model('TasksTodoBy', tasksTodoBySchema);