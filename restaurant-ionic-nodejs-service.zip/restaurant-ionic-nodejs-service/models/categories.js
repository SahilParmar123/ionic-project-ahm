const mongoose = require('mongoose');

const categoriesSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true },
    categoryId :{type: String, require: true},
    name: { type: String },
    sortOrder:{type:String}    
});


var Categories = module.exports = mongoose.model('Categories', categoriesSchema);

module.exports.createCategory = function (category, callback) {
    category.save(callback);
}

module.exports.updateCategory = function (category, callback) {
    Categories.updateOne({ _id: category._id }, { $set: category }, callback); 
}

module.exports.getAllCategory = function (callback){
    Categories.find(callback);
}