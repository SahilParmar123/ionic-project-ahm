const mongoose = require('mongoose');

const userTypeUsersSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true},
    userCode :{type: String, require: true,},
    userTypeId: { type: String, require: true }
});


var UserTypeUsers = module.exports = mongoose.model('UserTypeUser', userTypeUsersSchema);

module.exports.createUserType = function (userTypeUser, callback) {
    userTypeUser.userTypeId = 'pu';
    userTypeUser.save(callback);
}