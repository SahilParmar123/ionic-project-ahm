
var express = require('express'),
router = express.Router(),
languageController = require('../controller/languages');

//Master File
router.post('/addMasterLanguage', verifyToken, languageController.addMasterLanguage); 
router.get('/getAllMasterLanguages', verifyToken, languageController.getAllLanguages);
//Label Language
router.get('/getAllLabelLanguagesById/:_id', verifyToken, languageController.getAllLabelLanguagesById);
// router.post('/uploadLanguageMasterFile', verifyToken, languageController.uploadLanguageMasterFile); //Master File
router.post('/uploadLanguageLabelsFile/:_id', verifyToken, languageController.uploadLanguageLabelsFile); // Labels File

function verifyToken (req, res, next) {
    const bearerHeader = req.headers['authorization'];
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        req.token = bearerToken;
        next();
    } else {
        //Forbidden
        //return res.status(403);
        next();
    }
}

module.exports = router; 