
var express = require('express'),
router = express.Router(),
authController = require('../controller/auth');

router.post('/login', authController.login);
router.post('/register', authController.register);
router.post('/forgotPassword', authController.forgotPassword);
router.post('/resetPassword', authController.resetPassword); //Users
router.post('/resetPasswordEmail', verifyToken, authController.resetPasswordEmail); //Users
router.post('/changePassword', verifyToken, authController.changePassword); //Admin

function verifyToken (req, res, next) {
    const bearerHeader = req.headers['authorization'];
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        req.token = bearerToken;
        next();
    } else {
        //Forbidden
        //return res.status(403);
        next();
    }
}

module.exports = router; 