const jwt = require('jsonwebtoken');
var secret = 'restaurant-ionic-app';
const Restaurant = require('../models/restaurants');
const RestaurantUsers = require('../models/restaurantUsers');
const passport = require('passport');

exports.createRestaurant = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            var restaurant = new Restaurant(req.body);
            restaurant.createdDate = new Date();
            restaurant.statusIndicator = true;
            var num = Math.floor(Math.random() * 90000) + 10000;
            restaurant.restaurantCode =  new Date().getFullYear() + "REST" + num; 
            Restaurant.createRestaurant(restaurant, function (err, restaurant) {
                if (err) return res.json({status: 301, message: err, data:null});
                if (restaurant) {
                    return res.json({
                        status: 200,
                        message: 'Restaurant added..!',
                        data: restaurant
                    });
                }
            });
        }
    });
}

exports.updateRestaurant = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            var restaurant = req.body;
            Restaurant.updateRestaurant(restaurant, function (err, result) {
                if (err) return res.json({status: 301, message: err, data:null});
                if (result) {
                    return res.json({
                        status: 200,
                        message: 'Restaurant updated..!',
                        data: restaurant
                    });
                }
            });
        }
    });
}

exports.deleteRestaurant = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            var _id = req.body._id;
            Restaurant.findById(_id, function (err, restaurant) {
                if (err) {
                    return res.json({ status: 301, message: err });
                }
                if (restaurant) {
                    restaurant.statusIndicator = false;
                    Restaurant.updateRestaurant(restaurant, function (err, result) {
                        if (err) return res.json({status: 301, message: err, data:null});
                        if (result) {
                            return res.json({
                                status: 200,
                                message: 'Restaurant deleted success..!',
                                data: restaurant
                            });
                        }
                    });
                }else{
                    return res.json({
                        status: 301,
                        message: 'No Restaurant found..!',
                        data: null
                    });
                }
            });           
           
        }
    });
}

exports.getAllRestaurant = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            Restaurant.getAllRestaurant(function (err, restaurants) {
                if (err) return res.json({status: 301, message: err, data:null});
                if (restaurants) {
                    return res.json({
                        status: 200,
                        message: 'Restaurant list..!',
                        data: restaurants
                    });
                }
            });
        }
    });
}

exports.getAllRestaurantUsersById = function (req, res){
    jwt.verify(req.token, secret, function (err, user) {
        if (err) {
            return res.json({status: 301, message: err, data:null});
        } else {
            var restaurantCode = req.params.restaurantCode;
            RestaurantUsers.getAllRestaurantUsersById(restaurantCode, function (err, restaurantUsers) {
                if (err) return res.json({status: 301, message: err, data:null});
                if (restaurantUsers) {
                    return res.json({
                        status: 200,
                        message: '',
                        data: restaurantUsers
                    });
                }
            });
        }
    });
}