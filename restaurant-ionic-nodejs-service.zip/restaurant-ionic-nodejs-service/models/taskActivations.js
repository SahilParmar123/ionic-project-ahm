const mongoose = require('mongoose');

const taskActivationsSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true },
    taskId :{type: Number, require: true},
    activationIndex: { type: Number },
    activeFrom:{type:Date},
    activeUntil:{type:Date} 
});


var TaskActivations = module.exports = mongoose.model('TaskActivations', taskActivationsSchema);