
var express = require('express'),
router = express.Router(),
restaurantController = require('../controller/restaurants');

// Restaurant
router.post('/createRestaurant', verifyToken, restaurantController.createRestaurant);
router.post('/updateRestaurant', verifyToken, restaurantController.updateRestaurant);
router.post('/deleteRestaurant', verifyToken, restaurantController.deleteRestaurant);
router.get('/getAllRestaurant', verifyToken, restaurantController.getAllRestaurant);

// Restaurant Users
router.get('/getAllRestaurantUsersById/:restaurantCode', verifyToken, restaurantController.getAllRestaurantUsersById);

function verifyToken (req, res, next) {
    const bearerHeader = req.headers['authorization'];
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        req.token = bearerToken;
        next();
    } else {
        //Forbidden
        //return res.status(403);
        next();
    }
}

module.exports = router; 