const mongoose = require('mongoose');

const langLabelsSchema = mongoose.Schema({
    languageId:{ type: String, require: true }, //_id
    languagecode: { type: String, require: true }, //ar/fr/en
    languagetitle: { type: String }, 
    labelcode: { type: String },
    labelvalue: { type: String }
});


var LanguageLabels = module.exports = mongoose.model('LanguageLabels', langLabelsSchema);

module.exports.getAllLabelLanguagesById = function (_id, callback){
    var query = {'languageId': _id};
    LanguageLabels.find(query).select('labelvalue labelcode').exec(callback);
}
