
var express = require('express'),
router = express.Router(),
userController = require('../controller/users');

router.post('/createUser', userController.createUser);
router.get('/getAllUsers',verifyToken, userController.getAllUsers);
router.post('/delete', verifyToken, userController.delete);
router.post('/updateUser', verifyToken, userController.updateUser);
router.get('/getLoggedInUser', verifyToken, userController.getLoggedInUser);
router.post('/getAllUsersById', verifyToken, userController.getAllUsersById);
router.post('/profileImageChange', verifyToken, userController.profileImageChange);

//Change Email
router.post('/changeEmail', verifyToken, userController.changeEmail);
//Trigger Email
router.post('/triggerEmail', verifyToken, userController.triggerEmail);

function verifyToken (req, res, next) {
    const bearerHeader = req.headers['authorization'];
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        req.token = bearerToken;
        next();
    } else {
        //Forbidden
        //return res.status(403);
        next();
    }
}

module.exports = router; 