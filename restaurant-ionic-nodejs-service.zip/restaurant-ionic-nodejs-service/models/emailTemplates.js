const mongoose = require('mongoose');

const emailTemplatesSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true },
    language_code: { type: String, require: true },
    email_type: { type: String },
    email_subject: { type: String },
    email_message: { type: String }
});


var EmailTemplate = module.exports = mongoose.model('EmailTemplate', emailTemplatesSchema);

module.exports.updateEmailTemplate = function (emailTemp, callback) {
    EmailTemplate.updateOne({ _id: emailTemp._id }, { $set: emailTemp }, callback);
}

module.exports.getAllEmailTemplates = function (callback) {
    // EmailTemplate.find(callback);
    EmailTemplate.aggregate([
        //Group by fields and get all data
        { "$group": { "_id": "$email_type", "doc": { "$first": "$$ROOT" } } },
        { "$replaceRoot": { "newRoot": "$doc" } }
    ]).exec(callback);
}


module.exports.getAllEmailTemplatesByEmailType = function (type, callback) {
    var query = { "email_type": type };
    EmailTemplate.find(query, callback);
}