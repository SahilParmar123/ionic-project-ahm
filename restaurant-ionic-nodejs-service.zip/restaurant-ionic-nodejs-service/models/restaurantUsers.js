const mongoose = require('mongoose');

const restaurantUsersSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true, unique: true },
    userCode :{type: String, require: true,},
    restaurantUserStatusIndicator: { type: Number },
    workingDays: { type: String },
    pushTodoIndicator: { type: String, require: true },
    pushReportsIndicator: { type: String }
});


var RestaurantUser = module.exports = mongoose.model('RestaurantUser', restaurantUsersSchema);


module.exports.getAllRestaurantUsersById = function (restaurantCode, callback){
    var query = {'restaurantCode':restaurantCode};
    RestaurantUser.find(query, callback);
}