const mongoose = require('mongoose');

const remarksSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true, unique: true },
    userCode :{type: String, require: true,},
    restaurantUserStatusIndicator: { type: Number },
    workingDays: { type: String },
    pushTodoIndicator: { type: String, require: true },
    pushReportsIndicator: { type: String }
});


var Remark = module.exports = mongoose.model('Remark', remarksSchema);