const mongoose = require('mongoose');

const taskAssignedUserTypesSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true },
    taskId :{type: Number, require: true},
    userTypeId: { type: Number }
});


var TaskAssignedUserTypes = module.exports = mongoose.model('TaskAssignedUserTypes', taskAssignedUserTypesSchema);