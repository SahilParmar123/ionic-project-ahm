const LanguageMaster = require('../models/languageMaster');
const LanguageLabels = require('../models/languageLabels');
var secret = 'restaurant-ionic-app';
var multer = require('multer');
const jwt = require('jsonwebtoken');
var xlstojson = require("xls-to-json-lc");
var xlsxtojson = require("xlsx-to-json-lc");

exports.addMasterLanguage = function (req, res) {

    if (req.token != null) {
        jwt.verify(req.token, secret, function (err, user) {
            if (err) {
                return res.status(403);
            } else {
                var language = new LanguageMaster(req.body);
                language.languagecode = language.languagetitle.substring(0, 3).toLowerCase();
                LanguageMaster.addMasterLanguage(language, function (err, language) {
                    if (err) return res.json({ err, status: 'error' });
                    if (language) {
                        return res.json({
                            status: 200,
                            message: 'Language added..!',
                            data: language
                        });
                    }
                });
            }
        });

    } else {
        return res.json({
            message: "Token is not define..!",
            status: 1
        });
    }
}

exports.getAllLanguages = function (req, res) {
    if (req.token != null) {
        jwt.verify(req.token, secret, function (err, user) {
            if (err) {
                return res.status(403);
            } else {
                LanguageMaster.getAllLanguages(function (err, languages) {
                    if (err) throw err;
                    if (languages) {
                        return res.json({
                            status: 200,
                            message: '',
                            data: languages
                        });
                    }
                });
            }
        });
    } else {
        return res.json({
            message: "Token is not define..!",
            status: 1
        });
    }
}

exports.getAllLabelLanguagesById = function (req, res) {

    if (req.token != null) {
        jwt.verify(req.token, secret, function (err, user) {
            if (err) {
                return res.status(403);
            } else {
                var _id = req.params._id;
                LanguageLabels.getAllLabelLanguagesById(_id, function (err, languages) {
                    if (err) return res.json({ status: 301, message: err, data: null });
                    if (languages) {
                        return res.json({
                            status: 200,
                            message: '',
                            data: languages
                        });
                    }
                });
            }
        });
    } else {
        return res.json({
            message: "Token is not define..!",
            status: 1
        });
    }
}

exports.uploadLanguageMasterFile = function (req, res) {

    if (req.token != null) {
        var storage = multer.diskStorage({ //multers disk storage settings
            destination: function (req, file, cb) {
                cb(null, './uploads');
            },
            filename: function (req, file, cb) {
                var datetimestamp = Date.now();
                cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1])
            }
        });

        var upload = multer({ //multer settings
            storage: storage,
            fileFilter: function (req, file, callback) { //file filter
                if (['xls', 'xlsx'].indexOf(file.originalname.split('.')[file.originalname.split('.').length - 1]) === -1) {
                    return callback(new Error('Wrong extension type'));
                }
                callback(null, true);
            }
        }).single('file');

        var exceltojson;
        upload(req, res, function (err) {
            if (err) {
                res.json({ status: 1, message: err });
                return;
            }
            /** Multer gives us file info in req.file object */
            if (!req.file) {
                res.json({ status: 1, message: "No file passed" });
                return;
            }
            /** Check the extension of the incoming file and 
             *  use the appropriate module
             */
            if (req.file.originalname.split('.')[req.file.originalname.split('.').length - 1] === 'xlsx') {
                exceltojson = xlsxtojson;
            } else {
                exceltojson = xlstojson;
            }
            console.log(req.file.path);
            try {
                exceltojson({
                    input: req.file.path,
                    output: null, //since we don't need output.json
                    lowerCaseHeaders: true
                }, function (err, result) {
                    if (err) {
                        return res.json({ status: 1, message: err, data: null });
                    }
                    result.forEach(element => {
                        var language = new LanguageMaster(element);
                        language.save();
                    });
                    res.json({ status: 200, message: "File Uploaded..!" });
                });
            } catch (e) {
                res.json({ status: 1, message: "Corupted excel file" });
            }
        });
    } else {
        return res.json({
            message: "Token is not define..!",
            status: 1
        });
    }
}

exports.uploadLanguageLabelsFile = function (req, res) {

    if (req.token != null) {
        var _id = req.params._id;
        var storage = multer.diskStorage({ //multers disk storage settings
            destination: function (req, file, cb) {
                cb(null, './uploads');
            },
            filename: function (req, file, cb) {
                var datetimestamp = Date.now();
                cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length - 1])
            }
        });

        var upload = multer({ //multer settings
            storage: storage,
            fileFilter: function (req, file, callback) { //file filter
                if (['xls', 'xlsx'].indexOf(file.originalname.split('.')[file.originalname.split('.').length - 1]) === -1) {
                    return callback(new Error('Wrong extension type'));
                }
                callback(null, true);
            }
        }).single('file');

        var exceltojson;
        upload(req, res, function (err) {
            if (err) {
                res.json({ status: 1, message: err });
                return;
            }
            /** Multer gives us file info in req.file object */
            if (!req.file) {
                res.json({ status: 1, message: "No file passed" });
                return;
            }
            /** Check the extension of the incoming file and 
             *  use the appropriate module
             */
            if (req.file.originalname.split('.')[req.file.originalname.split('.').length - 1] === 'xlsx') {
                exceltojson = xlsxtojson;
            } else {
                exceltojson = xlstojson;
            }
            console.log(req.file.path);
            try {
                exceltojson({
                    input: req.file.path,
                    output: null, //since we don't need output.json
                    lowerCaseHeaders: true
                }, function (err, excelworkdata) {
                    if (err) {
                        return res.json({ status: 1, message: err, data: null });
                    }
                    // Find language code 
                    LanguageMaster.findById(_id, function (err, language) {
                        if (err) return res.json({
                            err,
                            status: 'error'
                        });
                        if (language) {
                            //Delete the all rows
                            LanguageLabels.deleteMany({ 'languageId': _id }, function (err, result) {
                                if (err) return res.json({ status: 301, message: err, data: null });
                                if (result) {
                                    
                                    excelworkdata.forEach(element => {
                                        var languageLbl = new LanguageLabels();
                                        languageLbl.labelvalue = Object.values(element)[0];
                                        languageLbl.labelcode = Object.values(element)[1];
                                        languageLbl.languageId = _id;
                                        languageLbl.languagetitle = language.languagetitle;
                                        languageLbl.languagecode = language.languagecode;
                                        languageLbl.save();
                                    });
                                    res.json({ status: 200, message: "File Uploaded..!" });
                                }
                            });
                        } else {
                            return res.json({
                                message: "Language Not found",
                                status: 'error'
                            });
                        }
                    });

                });
            } catch (e) {
                res.json({ status: 1, message: "Corupted excel file" });
            }
        });
    } else {
        return res.json({
            message: "Token is not define..!",
            status: 1
        });
    }
}