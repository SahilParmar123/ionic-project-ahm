
var express = require('express'),
router = express.Router(),
emailTemplatesController = require('../controller/emailTemplates');

router.post('/updateEmailTemplate', verifyToken, emailTemplatesController.updateEmailTemplate);
router.get('/getAllEmailTemplate', verifyToken, emailTemplatesController.getAllEmailTemplate);
router.post('/getAllEmailTemplatesByEmailType', verifyToken, emailTemplatesController.getAllEmailTemplatesByEmailType);

function verifyToken (req, res, next) {
    const bearerHeader = req.headers['authorization'];
    if (typeof bearerHeader !== 'undefined') {
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1];
        req.token = bearerToken;
        next();
    } else {
        //Forbidden
        //return res.status(403);
        next();
    }
}

module.exports = router; 