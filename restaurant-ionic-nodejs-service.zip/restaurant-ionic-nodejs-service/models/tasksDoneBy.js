const mongoose = require('mongoose');

const tasksDoneBySchema = mongoose.Schema({
    dateIndicator:{type:String},
    restaurantCode: { type: String},
    taskId: { type: Number },
    userCode:{type:String}
});


var TasksDoneBy = module.exports = mongoose.model('TasksDoneBy', tasksDoneBySchema);