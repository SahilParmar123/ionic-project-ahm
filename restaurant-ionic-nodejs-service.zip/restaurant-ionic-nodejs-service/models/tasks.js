const mongoose = require('mongoose');

const taskSchema = mongoose.Schema({
    restaurantCode: { type: String, require: true },
    taskId: { type: Number },
    groupIndicator: { type: Number },
    groupParentId: { type: Number },
    groupDisplayIndicator:{type:Number},
    recuringTaskIndicator:{type:Number},
    categoryId:{type:Number},
    name:{type:String},
    estimatedMinutes:{type:Number},
    privateIndicator:{type:Number},
    discription:{type: String},
    categorySortOrder:{type: String},
    groupSortOrder:{type: String},
    discription:{type: String}
});


var Task = module.exports = mongoose.model('Task', taskSchema);