const mongoose = require('mongoose');

const taskTodoSchema = mongoose.Schema({
    dateIndicator:{type:String},
    restaurantCode: { type: String},
    taskId: { type: Number },
});


var TasksTodo = module.exports = mongoose.model('TasksTodo', taskTodoSchema);